﻿using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;



public class SystemHotKey : Form
{
    public enum MODKEY
    {
        None = 0,
        ALT = 0x0001,
        CTRL = 0x0002,
        SHIFT = 0x0004,
        WIN = 0x0008,
    }
    private List<idAndFun> keyIds = new List<idAndFun>();
    private uint id = 0;

    [DllImport("user32.dll")]
    public static extern UInt32 RegisterHotKey(IntPtr hWnd, UInt32 id, UInt32 fsModifiers, UInt32 vk);

    [DllImport("user32.dll")]
    public static extern UInt32 UnregisterHotKey(IntPtr hWnd, UInt32 id);

    public SystemHotKey()
    {

    }
    public delegate void myfun();
    public void RegHotKey(Keys key, myfun e)
    {
        id++;
        idAndFun fi = new idAndFun();
        fi.id = id;
        fi.key = (uint)key;
        fi.mf = (object)e;
        keyIds.Add(fi);
        RegisterHotKey(this.Handle, id, 0, (uint)key);
    }

    public void RegHotKey(MODKEY keyvalue,Keys key, myfun e)
    {
        id++;
        idAndFun fi = new idAndFun();
        fi.id = id;
        fi.key = (uint)key;
        fi.mf = (object)e;
        keyIds.Add(fi);
        RegisterHotKey(this.Handle, id,(uint)keyvalue, (uint)key);
    }
    public void UnRegHotKey(Keys key)
    {
        uint temp = (uint)key;
        for (int i = 0; i < keyIds.Count; i++)
        {
            if (keyIds[i].key == temp)
            {
                UnregisterHotKey(this.Handle, keyIds[i].id);
                keyIds.RemoveAt(i);
            }
        }
    }
    protected override void WndProc(ref Message m)
    {
        const int WM_HOTKEY = 0x0312;
        if (m.Msg == WM_HOTKEY)
        {
            for (int i = 0; i < keyIds.Count; i++)
            {
                if (m.WParam.ToInt32() == keyIds[i].id)
                {
                    myfun mff = (myfun)keyIds[i].mf;
                    mff();
                }
            }
        }
        base.WndProc(ref m);
    }

}
class idAndFun
{
    public uint id;
    public uint key;
    public object mf;
}



