﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenCapture
{
    public partial class TargetForm : Form
    {
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        Rectangle bounds;
        Bitmap bitmap;

        bool Done = false;
        bool isDown = false;
        Point p_start = new Point();
        Point p_stop = new Point();

        static Image before;

        public TargetForm()
        {
            InitializeComponent();
            bounds = Screen.GetBounds(Screen.GetBounds(Point.Empty));
            bitmap = new Bitmap(bounds.Width, bounds.Height);
            Graphics g = Graphics.FromImage(bitmap);
            g.CopyFromScreen(Point.Empty,Point.Empty,bounds.Size);
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            BackgroundImage = bitmap;
            before = bitmap.Clone() as Image;
            menuStrip1.Visible = false;
        }

        private void TargetForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (!Done)
            {
                isDown = true;
                p_start.X = e.X;
                p_start.Y = e.Y;
            }
            else
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);

            }
        }

        private void TargetForm_MouseUp(object sender, MouseEventArgs e)
        {
            if (!Done)
            {
                Done = true;
                isDown = false;
                

                Size TargetSize = new Size(p_stop.X - p_start.X, p_stop.Y - p_start.Y);
                Bitmap TargetBitmap = new Bitmap(TargetSize.Width,TargetSize.Height);
                Rectangle TargetRec = new Rectangle(p_start, TargetSize);

                Location = p_start;
                this.WindowState = FormWindowState.Normal;
                Size = TargetSize;
                Visible = false;
                Graphics g = Graphics.FromImage(TargetBitmap);
                g.DrawImage(before, 0,0, TargetRec, GraphicsUnit.Pixel);
                g.DrawRectangle(new Pen(Color.Black), 0, 0, p_stop.X - p_start.X - 1, p_stop.Y - p_start.Y - 1);
                BackgroundImage = TargetBitmap;
                Visible = true;
   
                menuStrip1.Visible = true;
            }
        }

        private void TargetForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (!Done)
            {
                Graphics g = CreateGraphics();
                Pen myPen = new Pen(Color.DarkBlue);
                if (isDown == false)
                    return;
                p_stop.X = e.X;
                p_stop.Y = e.Y;

                Invalidate(true);
                BackgroundImage = before;                
            }

        }

        private void TargetForm_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (Done)
            {
                saveFileDialog1.FileName = DateTime.Now.Month.ToString() + "月" + DateTime.Now.Day.ToString() + "日";
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    BackgroundImage.Save(saveFileDialog1.FileName + ".bmp");
                    saveFileDialog1.Dispose();
                    
                }
            }
        }

        private void 放弃ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dispose();
            Close();
        }

        private void 保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.FileName = DateTime.Now.Month.ToString() + "月" + DateTime.Now.Day.ToString() + "日";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                BackgroundImage.Save(saveFileDialog1.FileName + ".bmp");
                saveFileDialog1.Dispose();

            }
        }

        private void menuStrip1_MouseDown(object sender, MouseEventArgs e)
        {            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
 

        }


        private void TargetForm_Paint(object sender, PaintEventArgs e)
        {
            if (!Done)
            {
                Pen myPen = new Pen(Color.DarkBlue);
                Graphics g = e.Graphics;
                BackgroundImage = before;
                g.DrawImage(before, bounds);
                g.DrawRectangle(myPen, p_start.X, p_start.Y, p_stop.X - p_start.X, p_stop.Y - p_start.Y);
            }

        }

        private void 置于前端ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Done)
            {
                if (TopMost == false)
                {
                    this.TopMost = true;
                    置于前端ToolStripMenuItem.Text = "取消置于前端";
                }
                else
                {
                    this.TopMost = false;
                    置于前端ToolStripMenuItem.Text = "置于前端";
                }
            }

        }
    }
}


